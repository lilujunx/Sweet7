package library.base;

/**
 * Created by Administrator on 2016/10/21.
 */
public class TitleBarConfig {
    //App是否使用标题栏
    public static boolean isUseTitleBar=true;
    //标题栏样式，R.layout.xxxx
    public static int titleBarResID;
}
