package com.example.ticket.ui.views;

/**
 * Created by Administrator on 2017/1/23.
 */

public interface OnItemClick {
        public void onClick(int position, String text);
        public void onLongClick(int position, String text);
}
