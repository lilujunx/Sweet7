package com.example.ticket.ui.fragment;


import android.support.v4.app.Fragment;

import com.example.ticket.base.TBaseFragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends TBaseFragment{

    @Override
    public int initRootLayout() {
        return 0;
    }

    @Override
    public void initViews() {

    }

    @Override
    public void initDatas() {

    }
}
