package com.example.ticket.entity.end;

/**
 * Created by Sai on 16/3/28.
 */
public class City {

    /**
     * cityName : 安顺
     * firstLetter : A
     */

    private String cityName;
    private String firstLetter;

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setFirstLetter(String firstLetter) {
        this.firstLetter = firstLetter;
    }

    public String getCityName() {
        return cityName;
    }

    public String getFirstLetter() {
        return firstLetter;
    }
}
