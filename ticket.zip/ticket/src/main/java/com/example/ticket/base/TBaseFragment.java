package com.example.ticket.base;


import library.base.BaseFragment;

/**
 * Created by Administrator on 2017/1/4.
 */

public abstract class TBaseFragment extends BaseFragment {

}
