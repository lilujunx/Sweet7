package com.example.ticket.base;

import android.os.Build;
import android.view.View;
import android.view.WindowManager;

import library.base.BaseActivity;


/**
 * Created by Administrator on 2017/1/4.
 */

public abstract class TBaseActivity extends BaseActivity {

}
